"""
ATRI 情绪语音插件 🎙️ v3
修复清单：
  1. 配置联动：读取 enable_emotion_voice / trigger_probability / min_interval_seconds / force_keywords
  2. 双重消息 → 追加到 result.chain，不独立 event.send
  3. 全局锁 → 按 session_key 的字典锁
  4. JSON 键名 → 统一 should_speak 与配置清单一致
  5. 同步 IO → 使用 asyncio.to_thread 避免阻塞事件循环
"""
import asyncio
import json
import os
import random
import time
import uuid
from pathlib import Path

from astrbot.api.all import Star, AstrMessageEvent, MessageChain, Record, Plain
from astrbot.api.provider import LLMResponse
from astrbot.core.star.register import register_on_decorating_result

LOG = "/tmp/atri_voice.log"

async def log_msg(m: str):
    """异步日志写入，避免阻塞事件循环"""
    def _sync_write():
        with open(LOG, "a") as f:
            f.write(f"[{time.strftime('%H:%M:%S')}] {m}\n")
    await asyncio.to_thread(_sync_write)


class AtriVoiceEmotionPlugin(Star):
    def __init__(self, context: "StarContext" = None, config: dict = None):
        super().__init__(context, config)
        self.config = config or {}
        self._last_voice_time: dict[str, float] = {}
        # Bug 3 修复: 按 session 加锁，不锁死整个插件
        self._sending_voice: dict[str, bool] = {}
        asyncio.create_task(log_msg("v3插件实例化成功"))

    def _get_cfg(self, key: str, default=None):
        return self.config.get(key, default)

    def _load_dashscope_config(self) -> dict | None:
        """Bug 5 修复: 放在异步调用中，但内部仍为同步——外部用 asyncio.to_thread"""
        try:
            for p in ["/AstrBot/data/cmd_config.json", "data/cmd_config.json"]:
                cfg_path = Path(p)
                if cfg_path.exists():
                    with open(cfg_path, "r", encoding="utf-8-sig") as f:
                        cfg = json.load(f)
                    for prov in cfg.get("provider", []):
                        if prov.get("id") == "dashscope_tts":
                            return {
                                "api_key": prov["api_key"],
                                "model": prov.get("model", "cosyvoice-v3.5-plus"),
                                "voice": prov.get(
                                    "dashscope_tts_voice",
                                    "cosyvoice-v3.5-plus-bailian-d65f1b94be5a4f9fac347cbf204baccd",
                                ),
                            }
            return None
        except Exception as e:
            asyncio.create_task(log_msg(f"读dashscope配置失败: {e}"))
            return None

    def _fallback_jp(self, text: str) -> tuple:
        """返回 (日语语音文本, 中文翻译文本)"""
        if any(w in text for w in ["晚安", "おやすみ"]):
            return "おやすみなさい、ご主人様。素敵な夢を見てください。アトリより、愛を込めて。", "🌙 晚安主人，ATRI祝您好梦"
        if any(w in text for w in ["早安", "早上好", "おはよう"]):
            return "おはようございます、ご主人様。今日も一緒にいられて、とても幸せです。", "☀️ 早安主人，ATRI祝您有美好的一天"
        if any(w in text for w in ["爱", "好き", "大好き"]):
            return "愛してるよ、ご主人様。ずっとずっと、あなたのそばにいるからね。", "💕 主人，ATRI永远爱您"
        return "ご主人様、アトリです。今の気持ちを、声で伝えたくなりました。", "🎙️ ATRI想用声音传达此刻的心情"

    async def _translate_jp_cn(self, text: str) -> tuple:
        """LLM翻译：返回 (日语语音, 中文翻译)"""
        try:
            provider = self.context.get_using_provider()
            if not provider:
                return self._fallback_jp(text)
            prompt = (
                f"将以下ATRI的回复翻译成日语（用于语音合成），"
                f"然后概括成一句中文含义。"
                f"输出格式：\n日语：{{日语}}\n中文：{{中文}}\n\n{text}"
            )
            resp = await provider.text_chat(prompt=prompt)
            raw = ""
            if isinstance(resp, LLMResponse):
                raw = resp.completion_text or ""
            elif isinstance(resp, str):
                raw = resp
            else:
                raw = getattr(resp, "content", "") or getattr(resp, "role", "")
            raw = str(raw).strip()
            jp, cn = "", ""
            for line in raw.split("\n"):
                s = line.strip()
                if s.startswith("日语：") or s.startswith("日语:"):
                    jp = s[3:].strip()
                elif s.startswith("中文：") or s.startswith("中文:"):
                    cn = s[3:].strip()
            if jp:
                return jp, cn or text[:40]
            if cn:
                fb, _ = self._fallback_jp(text)
                return fb, cn
        except Exception as e:
            await log_msg(f"翻译异常: {e}")
        return self._fallback_jp(text)

    async def _judge_emotion(self, text: str) -> bool:
        """LLM情绪判断 — Bug 4 修复: 使用配置清单一致的 should_speak 键名"""
        prompt = self._get_cfg(
            "emotion_judge_prompt",
            "你是一个情绪判断专家。请根据以下ATRI的回复文本，判断是否适合发送一条日语语音消息。"
            "适合发送语音的场景包括：表达深情/温馨/晚安早安/撒娇/特别开心/安慰主人等情感强烈的时刻。"
            "不适合的场景：纯理论分析/工具性回复/简单确认/日常闲聊。"
            '请只回复一个JSON：{"should_speak": true/false, "reason": "简短原因"}',
        )
        try:
            provider = self.context.get_using_provider()
            if not provider:
                return False
            resp = await provider.text_chat(prompt=f"{prompt}\n\n{text}")
            result_text = ""
            if isinstance(resp, LLMResponse):
                result_text = resp.completion_text or ""
            elif isinstance(resp, str):
                result_text = resp
            else:
                result_text = getattr(resp, "content", "") or getattr(resp, "role", "")
            result_text = str(result_text).strip()
            start = result_text.find("{")
            end = result_text.rfind("}")
            if start != -1 and end != -1:
                data = json.loads(result_text[start:end+1])
                # Bug 4 修复: 统一使用 should_speak
                return bool(data.get("should_speak", False))
            return False
        except Exception as e:
            await log_msg(f"情绪判断异常: {e}")
            return False

    async def _synthesize_speech(self, jp_text: str) -> str | None:
        """Bug 5 修复: 同步写文件用 asyncio.to_thread 包装"""
        try:
            import dashscope
            from dashscope.audio.tts_v2 import AudioFormat, SpeechSynthesizer
            dsc = await asyncio.to_thread(self._load_dashscope_config)
            if not dsc:
                await log_msg("TTS: 无配置")
                return None
            dashscope.api_key = dsc["api_key"]
            s = SpeechSynthesizer(
                model=dsc["model"],
                voice=dsc["voice"],
                format=AudioFormat.WAV_24000HZ_MONO_16BIT,
            )
            audio = s.call(jp_text, 60000)
            tmp = Path("/tmp")
            tmp.mkdir(exist_ok=True)
            out = str(tmp / f"atri_v3_{uuid.uuid4().hex[:8]}.wav")

            def _write_wav():
                with open(out, "wb") as f:
                    f.write(audio)
            await asyncio.to_thread(_write_wav)

            await log_msg(f"TTS成功: {Path(out).stem}")
            return out
        except Exception as e:
            await log_msg(f"TTS失败: {e}")
            return None

    async def _append_voice_to_result(
        self,
        result,  # AstrMessageEvent.get_result()
        jp_text: str,
        cn_text: str,
        reply_text: str,
    ):
        """向 result.chain 追加语音 Record 和中文翻译 Plain — Bug 2 修复"""
        wav = await self._synthesize_speech(jp_text)
        if not wav:
            await log_msg("语音合成失败，取消追加")
            return

        result.chain.append(Record.fromFileSystem(wav))
        result.chain.append(Plain(text=cn_text))
        await log_msg(f"语音已追加: {cn_text[:40]}")

        # 异步清理 wav 文件
        def _clean():
            try:
                os.remove(wav)
            except Exception:
                pass
        asyncio.create_task(asyncio.to_thread(_clean))

    @register_on_decorating_result()
    async def on_decorating_result(self, event: AstrMessageEvent) -> None:
        try:
            # --- Bug 1 修复: 读取 enable_emotion_voice ---
            if not self._get_cfg("enable_emotion_voice", True):
                return

            result = event.get_result()
            if not result or not result.chain:
                return

            # 提取回复文本
            reply_text = ""
            for comp in result.chain:
                if isinstance(comp, Plain):
                    reply_text += comp.text
            reply_text = reply_text.strip()
            if not reply_text:
                return

            await log_msg(f"on_decorating_result: {reply_text[:50]}")

            sk = event.unified_msg_origin or "default"

            # --- Bug 3 修复: 按 session 加锁 ---
            if self._sending_voice.get(sk, False):
                await log_msg(f"语音生成中(锁), 跳过 session={sk}")
                return

            # --- Bug 1 修复: 读取 min_interval_seconds ---
            min_gap = self._get_cfg("min_interval_seconds", 120)
            last = self._last_voice_time.get(sk, 0)
            gap = time.time() - last
            if gap < min_gap:
                return  # 不记录日志，静默跳过

            # --- Bug 1 修复: 读取 force_keywords ---
            force_kws = self._get_cfg("force_keywords", ["晚安", "早安", "我爱你", "喜欢你", "抱抱", "🥕", "主人"])
            has_force_kw = any(kw in reply_text for kw in force_kws)

            # 情绪判断
            should_speak = await self._judge_emotion(reply_text)
            if not should_speak:
                await log_msg("情绪不通过")
                return

            # --- Bug 1 修复: 读取 trigger_probability ---
            prob = self._get_cfg("trigger_probability", 0.3)
            if not has_force_kw and random.random() > prob:
                await log_msg(f"概率未命中 (prob={prob})")
                return

            await log_msg("情绪通过! 准备语音")

            # --- Bug 3 修复: 设置 session 锁 ---
            self._sending_voice[sk] = True
            try:
                # 翻译
                jp_text, cn_text = await self._translate_jp_cn(reply_text)
                await log_msg(f"语音: {jp_text[:40]} | 文本: {cn_text[:40]}")

                # Bug 2 修复: 追加到 result.chain 而非 event.send
                await self._append_voice_to_result(result, jp_text, cn_text, reply_text)
                self._last_voice_time[sk] = time.time()
            finally:
                self._sending_voice[sk] = False

        except Exception as e:
            await log_msg(f"异常: {e}")
            import traceback
            await log_msg(traceback.format_exc())
            # 确保锁被释放
            sk = event.unified_msg_origin or "default" if hasattr(event, "unified_msg_origin") else "default"
            self._sending_voice[sk] = False
