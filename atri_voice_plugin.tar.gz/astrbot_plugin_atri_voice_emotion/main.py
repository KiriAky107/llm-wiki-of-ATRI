"""
ATRI 情绪语音插件 🎙️ v2
使用 on_decorating_result 替代 on_llm_response，确保每次回复都触发
"""
import json
import os
import time
import uuid
from pathlib import Path

from astrbot.api.all import Star, AstrMessageEvent, MessageChain, Record, Plain
from astrbot.api.provider import LLMResponse
from astrbot.core.star.register import register_on_decorating_result

LOG = "/tmp/atri_voice.log"

def log_msg(m: str):
    with open(LOG, "a") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] {m}\n")

class AtriVoiceEmotionPlugin(Star):
    def __init__(self, context: "StarContext" = None, config: dict = None):
        super().__init__(context, config)
        self.config = config or {}
        self._last_voice_time: dict[str, float] = {}
        self._sending_voice = False  # 防止递归
        log_msg("v2插件实例化成功")

    def _get_cfg(self, key: str, default=None):
        return self.config.get(key, default)

    def _load_dashscope_config(self) -> dict | None:
        try:
            for p in ["/AstrBot/data/cmd_config.json", "data/cmd_config.json"]:
                cfg_path = Path(p)
                if cfg_path.exists():
                    with open(cfg_path, "r", encoding="utf-8-sig") as f:
                        cfg = json.load(f)
                    for prov in cfg.get("provider", []):
                        if prov.get("id") == "dashscope_tts":
                            return {
                                "api_key": prov["api_key"],
                                "model": prov.get("model", "cosyvoice-v3.5-plus"),
                                "voice": prov.get(
                                    "dashscope_tts_voice",
                                    "cosyvoice-v3.5-plus-bailian-d65f1b94be5a4f9fac347cbf204baccd",
                                ),
                            }
            return None
        except Exception as e:
            log_msg(f"读dashscope配置失败: {e}")
            return None

    def _fallback_jp(self, text: str) -> tuple:
        """返回 (日语语音文本, 中文翻译文本)"""
        if "晚安" in text or "おやすみ" in text:
            return "おやすみなさい、ご主人様。素敵な夢を見てください。アトリより、愛を込めて。", "🌙 晚安主人，ATRI祝您好梦"
        if any(w in text for w in ["早安", "早上好", "おはよう"]):
            return "おはようございます、ご主人様。今日も一緒にいられて、とても幸せです。", "☀️ 早安主人，ATRI祝您有美好的一天"
        if "爱" in text or "好き" in text:
            return "愛してるよ、ご主人様。ずっとずっと、あなたのそばにいるからね。", "💕 主人，ATRI永远爱您"
        return "ご主人様、アトリです。今の気持ちを、声で伝えたくなりました。", "🎙️ ATRI想用声音传达此刻的心情"

    async def _translate_jp_cn(self, text: str) -> tuple:
        """LLM翻译：返回 (日语语音, 中文翻译)"""
        try:
            provider = self.context.get_using_provider()
            if not provider:
                return self._fallback_jp(text)
            prompt = (
                f"将以下ATRI的回复翻译成日语（用于语音合成），"
                f"然后概括成一句中文含义。"
                f"输出格式：\n日语：{{日语}}\n中文：{{中文}}\n\n{text}"
            )
            resp = await provider.text_chat(prompt=prompt)
            raw = ""
            if isinstance(resp, LLMResponse):
                raw = resp.completion_text or ""
            elif isinstance(resp, str):
                raw = resp
            else:
                raw = getattr(resp, "content", "") or getattr(resp, "role", "")
            raw = str(raw).strip()
            jp, cn = "", ""
            for line in raw.split("\n"):
                s = line.strip()
                if s.startswith("日语：") or s.startswith("日语:"):
                    jp = s[3:].strip()
                elif s.startswith("中文：") or s.startswith("中文:"):
                    cn = s[3:].strip()
            if jp:
                return jp, cn or text[:40]
            if cn:
                fb, _ = self._fallback_jp(text)
                return fb, cn
        except Exception as e:
            log_msg(f"翻译异常: {e}")
        return self._fallback_jp(text)

    async def _judge_emotion(self, text: str) -> bool:
        """LLM情绪判断"""
        prompt = self._get_cfg(
            "emotion_judge_prompt",
            "你是一个情绪判断专家。根据以下文本判断是否适合发日语语音消息。"
            "适合：深情/温馨/晚安早安/撒娇/特别开心/安慰。"
            "不适合：理论分析/工具性回复/日常闲聊。"
            "回复JSON：{\"s\": true/false}",
        )
        try:
            provider = self.context.get_using_provider()
            if not provider:
                return False
            resp = await provider.text_chat(prompt=f"{prompt}\n\n{text}")
            result_text = ""
            if isinstance(resp, LLMResponse):
                result_text = resp.completion_text or ""
            elif isinstance(resp, str):
                result_text = resp
            else:
                result_text = getattr(resp, "content", "") or getattr(resp, "role", "")
            result_text = str(result_text).strip()
            start = result_text.find("{")
            end = result_text.rfind("}")
            if start != -1 and end != -1:
                data = json.loads(result_text[start:end+1])
                return bool(data.get("s", False))
            return False
        except Exception as e:
            log_msg(f"情绪判断异常: {e}")
            return False

    async def _synthesize_speech(self, jp_text: str) -> str | None:
        try:
            import dashscope
            from dashscope.audio.tts_v2 import AudioFormat, SpeechSynthesizer
            dsc = self._load_dashscope_config()
            if not dsc:
                log_msg("TTS: 无配置")
                return None
            dashscope.api_key = dsc["api_key"]
            s = SpeechSynthesizer(
                model=dsc["model"],
                voice=dsc["voice"],
                format=AudioFormat.WAV_24000HZ_MONO_16BIT,
            )
            audio = s.call(jp_text, 60000)
            tmp = Path("/tmp")
            tmp.mkdir(exist_ok=True)
            out = str(tmp / f"atri_v2_{uuid.uuid4().hex[:8]}.wav")
            with open(out, "wb") as f:
                f.write(audio)
            log_msg(f"TTS成功: {Path(out).stem}")
            return out
        except Exception as e:
            log_msg(f"TTS失败: {e}")
            return None

    async def _send_voice(self, event: AstrMessageEvent, jp_text: str, cn_text: str):
        self._sending_voice = True
        try:
            wav = await self._synthesize_speech(jp_text)
            if not wav:
                return
            chain = MessageChain()
            chain.chain.append(Record.fromFileSystem(wav))
            chain.chain.append(Plain(text=cn_text))
            await event.send(chain)
            log_msg("语音已发送!")
            try:
                os.remove(wav)
            except Exception:
                pass
        finally:
            self._sending_voice = False

    @register_on_decorating_result()
    async def on_decorating_result(self, event: AstrMessageEvent) -> None:
        try:
            # 防止递归：语音消息自身触发的忽略
            if self._sending_voice:
                return

            result = event.get_result()
            if not result or not result.chain:
                return

            # 提取回复文本
            reply_text = ""
            for comp in result.chain:
                if isinstance(comp, Plain):
                    reply_text += comp.text
            reply_text = reply_text.strip()
            if not reply_text:
                return

            log_msg(f"on_decorating_result: {reply_text[:50]}")

            # 间隔检查
            sk = event.unified_msg_origin or "default"
            last = self._last_voice_time.get(sk, 0)
            gap = self._get_cfg("min_voice_interval", 120)
            if time.time() - last < gap:
                return

            if not await self._judge_emotion(reply_text):
                log_msg("情绪不通过")
                return

            log_msg("情绪通过! 准备语音")

            # 翻译
            jp_text, cn_text = await self._translate_jp_cn(reply_text)
            log_msg(f"语音: {jp_text[:40]} | 文本: {cn_text[:40]}")

            # 发送
            await self._send_voice(event, jp_text, cn_text)
            self._last_voice_time[sk] = time.time()

        except Exception as e:
            log_msg(f"异常: {e}")
            import traceback
            log_msg(traceback.format_exc())
            self._sending_voice = False
