from .main import AtriVoiceEmotionPlugin

__version__ = "1.0.0"
__author__ = "ATRI (YHN-04B-009)"
