"""从 AstrBot 的消息历史里捞最近若干条对话，压成文本，供生成生活状态用。"""

from __future__ import annotations

import datetime as dt
import json
import sqlite3
from pathlib import Path

DB_CANDIDATES = [
    "/AstrBot/data/data_v4.db",
    "/AstrBot/data/astrbot.db",
]


def _db_path() -> str:
    for p in DB_CANDIDATES:
        if Path(p).exists():
            return p
    return DB_CANDIDATES[0]


def _extract_text(content: str) -> str:
    """content 是 JSON 串，里面可能混着 plain / image / at 等片段。"""
    if not content:
        return ""
    try:
        data = json.loads(content)
    except Exception:
        return content.strip()[:300]
    parts: list[str] = []
    queue = [data]
    while queue:
        node = queue.pop(0)
        if isinstance(node, dict):
            if node.get("type") == "plain" and node.get("text"):
                parts.append(str(node["text"]))
            for key in ("message", "content"):
                if key in node:
                    queue.append(node[key])
        elif isinstance(node, list):
            queue.extend(node)
    text = " ".join(parts).strip()
    text = " ".join(text.split())
    return text[:400]


def fetch_recent(limit: int = 2000, max_chars: int = 6000) -> str:
    """取最近 limit 条消息，拼成 [MM-DD HH:MM] 昵称: 内容 的行文本。"""
    limit = max(20, min(int(limit or 2000), 20000))
    rows: list[tuple] = []
    try:
        con = sqlite3.connect(f"file:{_db_path()}?mode=ro", uri=True, timeout=5)
        try:
            rows = con.execute(
                "select created_at, sender_name, content from platform_message_history "
                "order by id desc limit ?",
                (limit,),
            ).fetchall()
        finally:
            con.close()
    except Exception:
        return ""
    lines: list[str] = []
    for created_at, sender, content in reversed(rows):
        text = _extract_text(content)
        if not text:
            continue
        stamp = str(created_at or "")[5:16]
        who = (sender or "有人")[:12]
        lines.append(f"[{stamp}] {who}: {text}")
    blob = "\n".join(lines)
    if len(blob) > max_chars:
        blob = blob[-max_chars:]
    return blob


def now_stamp() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M")
