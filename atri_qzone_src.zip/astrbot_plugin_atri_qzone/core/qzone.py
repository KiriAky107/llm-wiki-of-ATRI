"""QQ 空间接口：取登录态、传图、发说说、点赞、拉评论、回复。

不依赖其他插件，cookies 直接从当前 OneBot 连接上取。
"""

from __future__ import annotations

import asyncio
import base64
import json
import time
from http.cookies import SimpleCookie
from typing import Any

import aiohttp
from astrbot.api import logger

BASE = "https://user.qzone.qq.com"
UPLOAD_URL = "https://up.qzone.qq.com/cgi-bin/upload/cgi_upload_image"
PUBLISH_URL = (
    "https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_publish_v6"
)
LIKE_URL = (
    "https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/likes/internal_dolike_app"
)
LIST_URL = (
    "https://user.qzone.qq.com/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_msglist_v6"
)
REPLY_URL = (
    "https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_re_feeds"
)
DETAIL_URL = (
    "https://h5.qzone.qq.com/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_msgdetail_v6"
)


def _gtk(skey: str) -> str:
    """算出 g_tk，空间接口几乎每个都要带。"""
    h = 5381
    for ch in skey:
        h += (h << 5) + ord(ch)
    return str(h & 0x7FFFFFFF)


async def _find_bot(context: Any) -> Any:
    """从平台管理器里找出可用的 aiocqhttp 连接。"""
    manager = getattr(context, "platform_manager", None)
    insts = []
    if manager is not None:
        getter = getattr(manager, "get_insts", None)
        if callable(getter):
            insts = list(getter() or [])
        else:
            insts = list(getattr(manager, "platform_insts", []) or [])
    for inst in insts:
        client = getattr(inst, "client", None) or getattr(inst, "bot", None)
        if client is not None and hasattr(client, "get_cookies"):
            return client
        if hasattr(inst, "get_cookies"):
            return inst
    return None


class QzoneClient:
    """一次性的空间会话，登录态按需刷新。"""

    def __init__(self, context: Any, *, timeout: int = 60) -> None:
        self.context = context
        self.timeout = timeout
        self._cookies = ""
        self._uin = 0
        self._skey = ""
        self._p_skey = ""
        self._gtk = ""
        self._fetched_at = 0.0

    async def _ensure(self, force: bool = False) -> None:
        if not force and self._cookies and time.monotonic() - self._fetched_at < 1500:
            return
        bot = await _find_bot(self.context)
        if bot is None:
            raise RuntimeError("找不到可用的 OneBot 连接，读不到空间登录态")
        payload = await bot.get_cookies(domain="user.qzone.qq.com")
        cookies_str = ""
        if isinstance(payload, dict):
            cookies_str = str(payload.get("cookies") or "").strip()
        if not cookies_str:
            raise RuntimeError("get_cookies 没有返回可用 Cookie")
        jar = {k: v.value for k, v in SimpleCookie(cookies_str).items()}
        uin_text = jar.get("uin", "0")
        raw = uin_text[1:] if uin_text[:1].lower() == "o" else uin_text
        if not raw.isdigit():
            raise RuntimeError("Cookie 里没有可用的 uin")
        self._cookies = cookies_str
        self._uin = int(raw)
        self._skey = jar.get("skey", "")
        self._p_skey = jar.get("p_skey", "") or self._skey
        self._gtk = _gtk(self._p_skey or self._skey)
        self._fetched_at = time.monotonic()

    @property
    def uin(self) -> int:
        return self._uin

    async def _post(self, session: aiohttp.ClientSession, url: str, data: dict, referer_uin: int = 0) -> str:
        await self._ensure()
        headers = {
            "Cookie": self._cookies,
            "Referer": f"{BASE}/{referer_uin or self._uin}",
            "Origin": BASE,
        }
        async with session.post(url, data=data, headers=headers, timeout=self.timeout) as resp:
            return await resp.text()

    async def upload_image(self, session: aiohttp.ClientSession, blob: bytes) -> bool:
        await self._ensure()
        data = {
            "filename": "filename",
            "uploadtype": "1",
            "albumtype": "7",
            "skey": self._skey,
            "uin": str(self._uin),
            "p_skey": self._p_skey,
            "output_type": "json",
            "base64": "1",
            "picfile": base64.b64encode(blob).decode(),
        }
        try:
            text = await self._post(session, UPLOAD_URL, data)
            ok = '"ret":0' in text.replace(" ", "") or "'ret':0" in text
            if not ok:
                logger.warning(f"[空间] 图片上传返回异常: {text[:200]}")
            return ok
        except Exception as exc:
            logger.warning(f"[空间] 图片上传失败: {exc}")
            return False

    async def publish(self, session: aiohttp.ClientSession, text: str, images: list[bytes] | None = None) -> dict:
        """发一条说说，返回接口原始结果。"""
        await self._ensure()
        images = images or []
        ok_count = 0
        for blob in images:
            if await self.upload_image(session, blob):
                ok_count += 1
                await asyncio.sleep(1.2)
        data = {
            "syn_tweet_verson": "1",
            "paramstr": "1",
            "who": "1",
            "con": text,
            "feedversion": "1",
            "ver": "1",
            "ugc_right": "1",
            "to_sign": "0",
            "hostuin": str(self._uin),
            "code_version": "1",
            "format": "json",
            "qzreferrer": f"{BASE}/{self._uin}",
            "g_tk": self._gtk,
        }
        raw = await self._post(session, PUBLISH_URL, data)
        try:
            body = json.loads(raw)
        except Exception:
            body = {"raw": raw[:300]}
        body["uploaded_images"] = ok_count
        return body

    async def like(self, session: aiohttp.ClientSession, tid: str, curkey: str = "") -> bool:
        await self._ensure()
        payload = (
            f"qzreferrer={BASE}/{self._uin}&opuin={self._uin}&unikey={BASE}/{self._uin}"
            f"&curkey={curkey or BASE}/{self._uin}&appid=311&from=1&type=0&fid={tid}"
            f"&object_type=1&action=2&format=json&g_tk={self._gtk}"
        )
        headers = {
            "Cookie": self._cookies,
            "Referer": f"{BASE}/{self._uin}",
            "Origin": BASE,
            "Content-Type": "application/x-www-form-urlencoded",
        }
        try:
            async with session.post(LIKE_URL, data=payload, headers=headers, timeout=self.timeout) as resp:
                text = await resp.text()
            return '"code":0' in text or '"ret":0' in text
        except Exception as exc:
            logger.warning(f"[空间] 点赞失败: {exc}")
            return False

    async def my_last_posts(self, session: aiohttp.ClientSession, count: int = 3) -> list[dict]:
        """拉自己最近几条说说，用来找评论。"""
        await self._ensure()
        params = {
            "uin": str(self._uin),
            "ftype": "0",
            "sort": "0",
            "pos": "0",
            "num": str(count),
            "replynum": "50",
            "g_tk": self._gtk,
            "callback": "_Callback",
            "code_version": "1",
            "format": "jsonp",
            "need_private_comment": "1",
        }
        headers = {"Cookie": self._cookies, "Referer": f"{BASE}/{self._uin}"}
        try:
            async with session.get(LIST_URL, params=params, headers=headers, timeout=self.timeout) as resp:
                text = await resp.text()
        except Exception as exc:
            logger.warning(f"[空间] 拉说说列表失败: {exc}")
            return []
        start, end = text.find("("), text.rfind(")")
        if start < 0 or end < 0:
            return []
        try:
            body = json.loads(text[start + 1 : end])
        except Exception:
            return []
        posts = []
        for item in body.get("msglist") or []:
            if not isinstance(item, dict):
                continue
            comments = []
            for c in item.get("commentlist") or []:
                if not isinstance(c, dict):
                    continue
                comments.append(
                    {
                        "id": str(c.get("commentid") or c.get("id") or ""),
                        "uin": str(c.get("uin") or ""),
                        "name": str(c.get("name") or c.get("nickname") or ""),
                        "content": str(c.get("content") or ""),
                        "tid": str(c.get("tid") or ""),
                        "reply": str(c.get("reply") or ""),
                    }
                )
            posts.append(
                {
                    "tid": str(item.get("tid") or ""),
                    "curkey": str(item.get("curkey") or ""),
                    "content": str(item.get("content") or ""),
                    "comments": comments,
                }
            )
        return posts

    async def reply_comment(
        self,
        session: aiohttp.ClientSession,
        *,
        tid: str,
        curkey: str,
        comment_uin: str,
        comment_id: str,
        text: str,
    ) -> bool:
        await self._ensure()
        data = {
            "topicId": tid,
            "feedsType": "0",
            "inCharset": "utf-8",
            "outCharset": "utf-8",
            "hostUin": str(self._uin),
            "format": "json",
            "ref": "feeds",
            "content": text,
            "plat": "qzone",
            "source": "ic",
            "platformid": "2",
            "uin": str(self._uin),
            "commentId": comment_id,
            "commentUin": comment_uin,
            "g_tk": self._gtk,
            "qzreferrer": curkey or f"{BASE}/{self._uin}",
        }
        try:
            raw = await self._post(session, REPLY_URL, data)
            ok = '"code":0' in raw or '"ret":0' in raw or '"subcode":0' in raw
            if not ok:
                logger.warning(f"[空间] 回复返回异常: {raw[:200]}")
            return ok
        except Exception as exc:
            logger.warning(f"[空间] 回复失败: {exc}")
            return False
