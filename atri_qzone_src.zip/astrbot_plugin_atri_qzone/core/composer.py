"""文案与配图。一次调用出一条说说，尽量少花 token。"""

from __future__ import annotations

import base64
import re
import json
from pathlib import Path
from typing import Any

import aiohttp
from astrbot.api import logger

from .persona import load_persona


async def _llm_text(
    context: Any, prompt: str, provider_id: str = "", system_prompt: str = ""
) -> str:
    """优先走框架的模型调用，失败则直连 DeepSeek。system_prompt 用全局人设。"""
    system_prompt = (system_prompt or "").strip()
    try:
        kwargs: dict[str, Any] = {"prompt": prompt}
        if provider_id:
            kwargs["chat_provider_id"] = provider_id
        if system_prompt:
            kwargs["system_prompt"] = system_prompt
        resp = await context.llm_generate(**kwargs)
        text = getattr(resp, "completion_text", "") or str(resp or "")
        if text.strip():
            return text.strip()
    except Exception as exc:
        logger.debug(f"[空间] 框架模型调用失败，改用直连: {exc}")

    cfg_path = Path("/AstrBot/data/cmd_config.json")
    if not cfg_path.exists():
        return ""
    data = json.loads(cfg_path.read_text(encoding="utf-8-sig"))
    sources = {
        str(s.get("id")): s for s in (data.get("provider_sources") or []) if isinstance(s, dict)
    }

    def _pick_key(entry: dict, src: dict) -> str:
        for holder in (entry, src):
            for field in ("api_key", "key"):
                raw = holder.get(field)
                if isinstance(raw, list):
                    raw = next((x for x in raw if x), "")
                if isinstance(raw, str) and raw.strip():
                    return raw.strip()
        return ""

    candidates: list[tuple[str, str, str]] = []
    for item in data.get("provider", []):
        if not isinstance(item, dict):
            continue
        src = sources.get(str(item.get("provider_source_id") or ""), {})
        base = str(
            item.get("api_base") or src.get("api_base") or "https://api.deepseek.com/v1"
        ).rstrip("/")
        if base.endswith("/chat/completions"):
            base = base[: -len("/chat/completions")]
        model = str(
            item.get("model")
            or (item.get("model_config") or {}).get("model")
            or "deepseek-chat"
        )
        alias = f"{item.get('id', '')} {model}"
        if provider_id:
            if provider_id not in (str(item.get("id")), model):
                continue
        elif "deepseek" not in alias:
            continue
        key = _pick_key(item, src)
        if key:
            candidates.append((base, key, model))

    for base, key, model in candidates:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": 600,
            "temperature": 0.8,
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{base}/chat/completions",
                    json=payload,
                    headers={"Authorization": f"Bearer {key}"},
                    timeout=90,
                ) as resp:
                    body = await resp.json()
            text = str(body["choices"][0]["message"]["content"]).strip()
            if text:
                return text
            logger.warning(f"[空间] 直连返回空（{model}）：{str(body)[:180]}")
        except Exception as exc:
            logger.warning(f"[空间] 直连失败（{model}）：{type(exc).__name__}: {exc}")
    return ""


def _clean(text: str) -> str:
    text = (text or "").strip()
    for mark in ("```", "──", "---"):
        text = text.replace(mark, "")
    text = text.strip().strip('"').strip("「」").strip()
    # 只保留前两句到四句，避免模型写长
    return text


def read_life_state() -> str:
    """只读生活插件的状态表，拿到此刻的心情和正在做的事。"""
    import sqlite3

    path = "/AstrBot/data/plugin_data/astrbot_plugin_daily_life/daily_life.db"
    if not Path(path).exists():
        return ""
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2.0)
        try:
            row = con.execute(
                "select mood, summary, updated_at from states order by rowid desc limit 1"
            ).fetchone()
        finally:
            con.close()
    except Exception as exc:
        logger.debug(f"[空间] 读取生活状态失败: {exc}")
        return ""
    if not row:
        return ""
    mood, summary, updated = (str(x or "").strip() for x in row)
    parts = []
    if mood:
        parts.append(f"心情是「{mood}」")
    if summary:
        parts.append(f"此刻{summary}")
    if not parts:
        return ""
    text = "；".join(parts)
    if updated:
        text += f"（{updated[11:16]} 更新）"
    return text


def read_recent_events(cfg: dict) -> str:
    """从最近的聊天记录里挑几行，作为今天发生的事。"""
    import datetime as _dt
    import json as _json

    hours = max(1, int(cfg.get("context_hours", 3) or 3))
    budget = max(120, int(cfg.get("context_chars", 500) or 500))
    folder = Path("/AstrBot/data/plugin_data/astrbot_plugin_history")
    if not folder.exists():
        return ""
    since = _dt.datetime.now() - _dt.timedelta(hours=hours)
    files = sorted(folder.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)[:4]
    lines: list[str] = []
    seen: set[str] = set()
    for file in files:
        taken = 0
        try:
            content = file.read_text(encoding="utf-8", errors="ignore").splitlines()[-120:]
        except Exception:
            continue
        for raw in reversed(content):
            if taken >= 6:
                break
            try:
                item = _json.loads(raw)
            except Exception:
                continue
            stamp = str(item.get("timestamp") or "")
            try:
                moment = _dt.datetime.fromisoformat(stamp)
            except Exception:
                continue
            if moment < since:
                continue
            text = str(item.get("content") or "")
            text = re.sub(r"\[MSG_ID:[^\]]*\]", "", text)
            text = text.replace("**", "").replace("*", "")
            text = re.sub(r"\s+", " ", text).strip()
            if len(text) < 4 or text in seen:
                continue
            if not re.search(r"[\u4e00-\u9fa5A-Za-z]", text):
                continue
            is_me = item.get("role") == "assistant"
            limit = 40 if is_me else 60
            seen.add(text)
            lines.append(f"{'我' if is_me else '有人'}：{text[:limit]}")
            taken += 1
    if not lines:
        return ""
    joined = "\n".join(lines[-40:])
    return joined[-budget:]


def gather_context(cfg: dict) -> str:
    if not bool(cfg.get("context_enabled", True)):
        return ""
    blocks = []
    state = read_life_state()
    if state:
        blocks.append(f"【我此刻的状态】{state}")
    events = read_recent_events(cfg)
    if events:
        blocks.append(f"【最近发生的事】\n{events}")
    return "\n\n".join(blocks)


async def compose_text(context: Any, cfg: dict, extra: str = "") -> str:
    prompt = str(cfg.get("post_prompt") or "").strip()
    context_block = gather_context(cfg)
    if context_block and not extra:
        prompt = (
            f"{prompt}\n\n下面是我此刻的真实状态和刚发生的事，"
            f"说说要从里面挑一件真的想讲的来写，别编：\n{context_block}"
        )
    if extra:
        prompt = f"{prompt}\n\n补充要求：{extra}"
    text = await _llm_text(
        context,
        prompt,
        str(cfg.get("text_provider") or ""),
        load_persona(str(cfg.get("persona_id") or "")),
    )
    return _clean(text)


async def compose_image(cfg: dict, text: str) -> bytes:
    """按说说内容出一张配图，返回图片字节。"""
    api = str(cfg.get("image_api_url") or "").rstrip("/")
    key = str(cfg.get("image_api_key") or "")
    model = str(cfg.get("image_model") or "agnes-image-2.1-flash")
    if not api or not key:
        logger.warning("[空间] 生图接口未配置，跳过配图")
        return b""

    style = str(cfg.get("image_style_prompt") or "").strip()
    prompt = f"{style}\n场景：{text}"
    ratio = str(cfg.get("image_ratio") or "1:1")
    size_map = {"1:1": "1024x1024", "3:4": "768x1024", "4:3": "1024x768", "16:9": "1280x720"}
    payload: dict[str, Any] = {
        "model": model,
        "prompt": prompt[:2000],
        "size": size_map.get(ratio, "1024x1024"),
        "n": 1,
    }

    ref_path = Path(str(cfg.get("reference_image") or ""))
    if bool(cfg.get("image_use_reference")) and ref_path.exists():
        raw = base64.b64encode(ref_path.read_bytes()).decode()
        payload["extra_body"] = {"response_format": "url", "image": [raw]}
    else:
        payload["response_format"] = "url"

    timeout = int(cfg.get("image_timeout") or 120)
    async with aiohttp.ClientSession() as s:
        async with s.post(
            f"{api}/images/generations",
            json=payload,
            headers={"Authorization": f"Bearer {key}"},
            timeout=timeout,
        ) as resp:
            body = await resp.json()
            if resp.status != 200:
                logger.warning(f"[空间] 生图失败 {resp.status}: {str(body)[:200]}")
                return b""
        url = ""
        try:
            item = (body.get("data") or [{}])[0]
            url = str(item.get("url") or "")
            b64 = str(item.get("b64_json") or "")
            if b64:
                return base64.b64decode(b64)
        except Exception:
            url = ""
        if not url:
            logger.warning(f"[空间] 生图没有返回地址: {str(body)[:200]}")
            return b""
        try:
            async with s.get(url, timeout=timeout) as img:
                if img.status != 200:
                    return b""
                return await img.read()
        except Exception as exc:
            logger.warning(f"[空间] 配图下载失败: {exc}")
            return b""
