"""读全局人设：所有生成都用同一份系统提示，不在插件里另写一套身份。"""

from __future__ import annotations

import sqlite3
from pathlib import Path

DB_CANDIDATES = [
    "/AstrBot/data/data_v4.db",
    "/AstrBot/data/astrbot.db",
]
DEFAULT_PERSONA_ID = "ATRI"

_cache: dict[str, str] = {}


def load_persona(persona_id: str = DEFAULT_PERSONA_ID) -> str:
    """取人设正文。找不到就返回空串，由调用方退化成“没有 system”。"""
    pid = (persona_id or DEFAULT_PERSONA_ID).strip()
    if pid in _cache:
        return _cache[pid]
    prompt = ""
    for db in DB_CANDIDATES:
        if not Path(db).exists():
            continue
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
            try:
                row = con.execute(
                    "select system_prompt from personas where persona_id = ? "
                    "order by updated_at desc limit 1",
                    (pid,),
                ).fetchone()
            finally:
                con.close()
        except Exception:
            continue
        if row and row[0]:
            prompt = str(row[0]).strip()
            break
    _cache[pid] = prompt
    return prompt


def clear_cache() -> None:
    _cache.clear()
