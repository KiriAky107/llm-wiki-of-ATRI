"""轻量生活状态：不依赖任何插件，按时段给出当下在做什么。

同一天同一时段的结果固定，用日期做种子，避免每分钟变一次。
"""

from __future__ import annotations

import datetime as dt
import json
import random
import re
from typing import Any

PERIODS = [
    (5, 8, "早晨"),
    (8, 11, "上午"),
    (11, 14, "中午"),
    (14, 17, "下午"),
    (17, 19, "傍晚"),
    (19, 22, "晚上"),
    (22, 29, "深夜"),  # 22 点后跨夜，用 24+ 表示
]

POOL = {
    "早晨": {
        "acts": ["把窗帘拉开，看了一会儿天", "洗了脸，头发还半湿着", "热了牛奶，站在窗边慢慢喝"],
        "places": ["厨房", "窗边"],
        "outfits": ["浅蓝色家居服", "白色长袖睡裙"],
        "moods": ["还有点困", "清醒了一点"],
    },
    "上午": {
        "acts": ["在阳台晒太阳补能源", "把房间收拾了一遍", "坐在地板上翻绘本"],
        "places": ["阳台", "客厅"],
        "outfits": ["米白毛衣配深蓝长裙", "浅灰针织开衫"],
        "moods": ["清爽", "有点懒", "心满意足"],
    },
    "中午": {
        "acts": ["捏了几个饭团，偷偷多放了一点蟹肉", "把厨房擦干净，锅倒扣着晾", "煮了汤，等它凉一点"],
        "places": ["厨房", "餐桌旁"],
        "outfits": ["系着围裙", "米色家居服配软鞋"],
        "moods": ["很满足", "被热汤熏得暖暖的"],
    },
    "下午": {
        "acts": ["去商店街转了转，顺路进了书店", "在书店站了很久，最后只买了一本", "拎着袋子回来，路上风有点凉"],
        "places": ["商店街", "书店"],
        "outfits": ["针织开衫配连衣裙，戴着贝雷帽", "浅色外套配短靴"],
        "moods": ["不急着回去", "心里轻快"],
    },
    "傍晚": {
        "acts": ["把买回来的东西分门别类放好", "站在灶台前准备晚饭", "把窗户开了一条缝透气"],
        "places": ["厨房", "阳台"],
        "outfits": ["围裙底下是米白毛衣"],
        "moods": ["安静下来", "有点期待这顿饭"],
    },
    "晚上": {
        "acts": ["把碗刷完，坐在灯下翻笔记本", "刚洗完澡，头发还湿着", "把今天的几行字写完", "翻了两页绘本就有点困"],
        "places": ["书桌边", "床上"],
        "outfits": ["睡衣", "浅蓝睡裙搭着毛毯"],
        "moods": ["困意浮浮的", "心里踏实"],
    },
    "深夜": {
        "acts": ["把笔记本合上，放回抽屉边", "关灯之前又看了眼窗外", "缩进被子里，只留一盏小灯"],
        "places": ["房间", "床上"],
        "outfits": ["睡衣"],
        "moods": ["很困", "安静得听得见风声"],
    },
}

WEATHER = ["晴朗", "薄云", "风有点凉", "天蓝得很干净", "阴着，光线淡淡的"]

DEFAULT_SLOTS = ["07:00", "12:00", "18:00", "22:00"]


def normalize_slots(raw: Any) -> list[str]:
    """把配置里的刷新时段整理成 ["07:00", ...] 有序列表。"""
    if isinstance(raw, str):
        items = re.split(r"[,，\s]+", raw.strip())
    elif isinstance(raw, (list, tuple)):
        items = [str(x) for x in raw]
    else:
        items = []
    out: list[str] = []
    for item in items:
        m = re.match(r"^(\d{1,2}):(\d{2})$", str(item).strip())
        if not m:
            continue
        hour, minute = int(m.group(1)), int(m.group(2))
        if 0 <= hour < 24 and 0 <= minute < 60:
            out.append(f"{hour:02d}:{minute:02d}")
    if not out:
        out = list(DEFAULT_SLOTS)
    return sorted(set(out))


def current_slot(moment: dt.datetime, slots: list[str]) -> str:
    """返回这一刻应该用的那个时段标签（最近一个已经过去的刷新点）。"""
    now_min = moment.hour * 60 + moment.minute
    marks = [(int(s[:2]) * 60 + int(s[3:]), s) for s in slots]
    picked = None
    for mins, label in marks:
        if mins <= now_min:
            picked = label
    if picked is None:
        picked = marks[-1][1] if marks else "07:00"
    return picked


def period_of(moment: dt.datetime) -> str:
    hour = moment.hour
    if hour >= 22:
        return "深夜"
    for start, end, name in PERIODS:
        if start <= hour < min(end, 24):
            return name
    return "清晨" if hour < 5 else "晚上"


def status_of(moment: dt.datetime) -> dict:
    """给出这一刻的简短状态。"""
    period = period_of(moment)
    bucket = POOL.get(period, POOL["晚上"])
    seed = f"{moment.date().isoformat()}-{period}"
    rng = random.Random(seed)
    act = rng.choice(bucket["acts"])
    place = rng.choice(bucket["places"])
    outfit = rng.choice(bucket["outfits"])
    mood = rng.choice(bucket["moods"])
    weather = rng.choice(WEATHER)
    return {
        "period": period,
        "act": act,
        "place": place,
        "outfit": outfit,
        "mood": mood,
        "weather": weather,
        "text": f"{period}，在{place}{act}，{mood}；外面{weather}",
    }


LIFE_PROMPT = """现在要写的是"我此刻在做什么"，用第一人称，不要自称名字。
现在是 {stamp}。

下面是我最近看过的对话记录（越靠后越近）：
---
{logs}
---

我上一次的状态是：{prev}

请根据现在的时间、上面的记录、以及一个普通女孩一天该怎么过，写出我"此刻"的状态。
只输出一个 JSON 对象，不要解释、不要代码块：
{{"period": "中午", "place": "厨房和餐桌", "act": "捏蟹肉饭团，手上还沾着米粒", "outfit": "米白毛衣配深蓝长裙", "mood": "满足", "weather": "薄云", "note": "有一个饭团里多塞了点蟹肉"}}

要求：
- period 用两三个字，比如 清晨、上午、中午、下午、傍晚、晚上、深夜。
- act 写成短句，不要以"正在"开头，不写长句。
- 都是身边的小事：做饭、打扫、晒太阳、翻绘本、买东西、等主人回家。
- 不要复述记录里的具体内容，不要出现人名、群名、账号。
- 如果记录显示主人深夜还在忙，就写我陪在旁边、有点担心。
- 如果和上一次状态相隔不久，就接着往下写，别跳得太远。"""


def _parse_json(raw: str) -> dict:
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"```\s*$", "", text).strip()
    start, end = text.find("{"), text.rfind("}")
    if start >= 0 and end > start:
        text = text[start : end + 1]
    try:
        data = json.loads(text)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


async def generate_status(llm_call, moment: dt.datetime, logs: str, prev: dict | None = None) -> dict:
    """让模型根据最近的日志写出这一刻的状态。失败时返回空 dict。"""
    prev_desc = "（还没有记录）"
    if prev:
        prev_desc = (
            f"{prev.get('period', '')}在{prev.get('place', '')}"
            f"{prev.get('act', '')}，{prev.get('mood', '')}"
        )
    prompt = LIFE_PROMPT.format(
        stamp=moment.strftime("%Y-%m-%d %H:%M"),
        logs=(logs or "（最近的记录很少，就按平常的样子写）")[:6000],
        prev=prev_desc,
    )
    try:
        raw = await llm_call(prompt)
    except Exception:
        raise
    data = _parse_json(raw if isinstance(raw, str) else str(raw))
    if not data:
        try:
            from astrbot.api import logger

            logger.warning(f"[空间] 状态解析失败，模型原文：{(raw or '')[:200]!r}")
        except Exception:
            pass
        return {}
    period = str(data.get("period") or period_of(moment))[:8]
    place = str(data.get("place") or "家里")[:24]
    act = str(data.get("act") or "在屋里慢慢做自己的事")[:60]
    outfit = str(data.get("outfit") or "家居服")[:40]
    mood = str(data.get("mood") or "平静")[:24]
    weather = str(data.get("weather") or "晴朗")[:20]
    note = str(data.get("note") or "")[:80]
    return {
        "period": period,
        "place": place,
        "act": act,
        "outfit": outfit,
        "mood": mood,
        "weather": weather,
        "note": note,
        "text": f"{period}，在{place}{act}，{mood}；外面{weather}",
        "source": "model",
        "at": moment.strftime("%Y-%m-%d %H:%M"),
    }


def scene_hint(status: dict) -> str:
    """给生图用的画面提示。"""
    return (
        f"场景：{status['place']}，{status['act']}；"
        f"人物穿着{status['outfit']}，神情{status['mood']}；光线{status['weather']}"
    )
