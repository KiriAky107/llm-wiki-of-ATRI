"""ATRI 空间说说：定时发布、文案配图、评论回复、黑名单。

排期有三种模式：固定点、时段内随机、模型自己挑。
"""

from __future__ import annotations

import asyncio
import datetime as dt
import json
import random
from pathlib import Path
from typing import Any

import aiohttp
from astrbot.api import logger
from astrbot.api.star import Context, Star, register

from .core.composer import _llm_text, compose_image, compose_text
from .core.life import (
    current_slot,
    generate_status,
    normalize_slots,
    scene_hint,
    status_of as life_status,
)
from .core.logfetch import fetch_recent
from .core.persona import load_persona
from .core.qzone import QzoneClient

STATE_FILE = Path("/AstrBot/data/plugin_data/astrbot_plugin_atri_qzone/state.json")


def _load_state() -> dict:
    try:
        if STATE_FILE.exists():
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {"replied": [], "log": []}


def _save_state(state: dict) -> None:
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        logger.warning(f"[空间] 状态保存失败: {exc}")


def _parse_hm(value: str) -> dt.time | None:
    try:
        h, m = str(value).strip().split(":")
        return dt.time(int(h), int(m))
    except Exception:
        return None


def _in_quiet(moment: dt.datetime, quiet: list) -> bool:
    for span in quiet or []:
        try:
            start_s, end_s = str(span).split("-", 1)
        except ValueError:
            continue
        start, end = _parse_hm(start_s), _parse_hm(end_s)
        if not start or not end:
            continue
        t = moment.time()
        if start <= end:
            if start <= t <= end:
                return True
        elif t >= start or t <= end:
            return True
    return False


@register("astrbot_plugin_atri_qzone", "ATRI", "轻量 QQ 空间说说", "1.0.0")
class AtriQzone(Star):
    def __init__(self, context: Context, config: Any = None):
        super().__init__(context)
        self.config = config or {}
        self.state = _load_state()
        self._plan_date = ""
        self._plan: list[dt.datetime] = []
        self._published: set[str] = set()
        self._next_reply_check = 0.0
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()

    async def initialize(self) -> None:
        self._register_web_api()
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop(), name="atri_qzone_loop")
        logger.info("[空间] 说说插件已就绪")

    def _register_web_api(self) -> None:
        routes = [
            ("page/status", self._api_status, ["GET"], "空间说说状态"),
            ("page/run", self._api_run, ["POST"], "立即发布一条"),
            ("page/replan", self._api_replan, ["POST"], "重算今日排期"),
            ("page/logs", self._api_logs, ["GET"], "发布记录"),
            ("page/life", self._api_life, ["GET"], "此刻状态"),
            ("page/config", self._api_config_get, ["GET"], "读取设置"),
            ("page/config/save", self._api_config_set, ["POST"], "保存设置"),
        ]
        for endpoint, handler, methods, desc in routes:
            try:
                self.context.register_web_api(
                    f"/astrbot_plugin_atri_qzone/{endpoint}", handler, methods, desc
                )
            except Exception as exc:
                logger.warning(f"[空间] 面板接口注册失败 {endpoint}: {exc}")

    async def _api_status(self):
        from quart import jsonify

        return jsonify(
            {
                "ok": True,
                "data": {
                    "mode": self._cfg("schedule_mode", "random"),
                    "window": self._cfg("random_window", "08:00-22:00"),
                    "daily_count": self._cfg("daily_count", 3),
                    "plan": [m.strftime("%H:%M") for m in self._plan],
                    "date": self._plan_date,
                    "published": sorted(self._published),
                    "image_enabled": bool(self._cfg("image_enabled", True)),
                    "reply_enabled": bool(self._cfg("reply_enabled", True)),
                    "replied_count": len(self.state.get("replied") or []),
                    "blacklist": list(self._cfg("reply_blacklist") or []),
                },
            }
        )

    async def _api_run(self):
        from quart import jsonify

        asyncio.create_task(self._publish_once())
        return jsonify({"ok": True, "data": {"message": "已开始发布，稍后看记录"}})

    async def _api_replan(self):
        from quart import jsonify

        today = dt.date.today()
        self._plan = await self._build_plan(today)
        self._plan_date = today.isoformat()
        return jsonify(
            {"ok": True, "data": {"plan": [m.strftime("%H:%M") for m in self._plan]}}
        )

    async def _api_logs(self):
        from quart import jsonify

        return jsonify({"ok": True, "data": {"log": (self.state.get("log") or [])[-20:]}})

    async def _api_life(self):
        from quart import jsonify

        now = dt.datetime.now()
        status = self._current_life(now)
        slots = normalize_slots(self._cfg("life_slots"))
        slot = current_slot(now, slots)
        nxt = next((s for s in slots if s > now.strftime("%H:%M")), slots[0] if slots else "")
        status = dict(status)
        status.update(
            {
                "slot": slot,
                "slots": slots,
                "next_slot": nxt,
                "enabled": bool(self._cfg("life_enabled")),
                "log_limit": int(self._cfg("life_log_limit") or 2000),
            }
        )
        return jsonify({"ok": True, "data": status})

    CONFIG_KEYS = [
        "schedule_mode",
        "persona_id",
        "life_enabled",
        "life_slots",
        "life_log_limit",
        "life_log_chars",
        "life_provider",
        "fixed_times",
        "random_window",
        "daily_count",
        "min_gap_minutes",
        "quiet_hours",
        "smart_count",
        "smart_hint",
        "post_prompt",
        "image_enabled",
        "image_ratio",
        "image_use_reference",
        "auto_like",
        "reply_enabled",
        "reply_schedule_mode",
        "reply_slots",
        "reply_interval_minutes",
        "reply_max_per_round",
        "reply_prompt",
        "reply_blacklist",
    ]

    async def _api_config_get(self):
        from quart import jsonify

        return jsonify(
            {"ok": True, "data": {k: self._cfg(k) for k in self.CONFIG_KEYS}}
        )

    async def _api_config_set(self):
        from quart import jsonify, request

        body = await request.get_json(silent=True) or {}
        changed = []
        for key, value in (body or {}).items():
            if key not in self.CONFIG_KEYS:
                continue
            try:
                self.config[key] = value
                changed.append(key)
            except Exception as exc:
                logger.warning(f"[空间] 配置写入失败 {key}: {exc}")
        saved = True
        try:
            saver = getattr(self.config, "save_config", None)
            if callable(saver):
                saver()
            else:
                data = dict(self.config)
                Path("/AstrBot/data/config/astrbot_plugin_atri_qzone_config.json").write_text(
                    json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
                )
        except Exception as exc:
            logger.warning(f"[空间] 配置保存失败: {exc}")
            saved = False
        if "schedule_mode" in changed or "random_window" in changed or "daily_count" in changed:
            self._plan_date = ""
            self._plan = []
        return jsonify(
            {"ok": True, "data": {"changed": changed, "saved": saved}}
        )

    async def terminate(self) -> None:
        self._stop.set()
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        _save_state(self.state)

    def _cfg(self, key: str, default: Any = None) -> Any:
        try:
            value = self.config.get(key, default)
        except Exception:
            value = default
        return default if value is None else value

    # ---------------- 排期 ----------------

    async def _build_plan(self, today: dt.date) -> list[dt.datetime]:
        mode = str(self._cfg("schedule_mode", "random")).lower()
        quiet = list(self._cfg("quiet_hours", []))
        out: list[dt.datetime] = []

        if mode == "fixed":
            for item in self._cfg("fixed_times", []) or []:
                t = _parse_hm(item)
                if t:
                    out.append(dt.datetime.combine(today, t))

        elif mode == "smart":
            out = await self._smart_plan(today)

        if mode in ("random", "smart") and not out:
            window = str(self._cfg("random_window", "08:00-22:00"))
            try:
                start_s, end_s = window.split("-", 1)
            except ValueError:
                start_s, end_s = "08:00", "22:00"
            start, end = _parse_hm(start_s) or dt.time(8, 0), _parse_hm(end_s) or dt.time(22, 0)
            begin = dt.datetime.combine(today, start)
            close = dt.datetime.combine(today, end)
            if close <= begin:
                close = begin + dt.timedelta(hours=4)
            count = max(1, int(self._cfg("daily_count", 3) or 3))
            span = (close - begin).total_seconds() / count
            gap = float(self._cfg("min_gap_minutes", 90) or 0) * 60
            for i in range(count):
                seg_start = begin.timestamp() + span * i
                seg_end = begin.timestamp() + span * (i + 1)
                pick = random.uniform(seg_start, max(seg_start, seg_end - 1))
                if out and gap and pick - out[-1].timestamp() < gap:
                    pick = out[-1].timestamp() + gap
                out.append(dt.datetime.fromtimestamp(pick))

        cleaned = sorted(m for m in out if not _in_quiet(m, quiet) and m.date() == today)
        if cleaned:
            logger.info(
                "[空间] 今日排期 " + ", ".join(m.strftime("%H:%M") for m in cleaned)
            )
        return cleaned

    async def _smart_plan(self, today: dt.date) -> list[dt.datetime]:
        count = max(1, int(self._cfg("smart_count", 2) or 2))
        window = str(self._cfg("random_window", "08:00-22:00"))
        hint = str(self._cfg("smart_hint") or "")
        quiet = "、".join(str(x) for x in (self._cfg("quiet_hours") or []))
        prompt = (
            f"今天是 {today.isoformat()}。请在 {window} 之间挑 {count} 个时间点发空间说说。"
            f"必须避开 {quiet or '无'}。{hint}\n"
            f"只输出时间，用逗号分开，例如 09:20,14:05,21:40。不要解释。"
        )
        text = await compose_text(self.context, {"post_prompt": prompt}, "")
        picks: list[dt.datetime] = []
        for token in str(text).replace("，", ",").split(","):
            t = _parse_hm(token.strip())
            if t:
                picks.append(dt.datetime.combine(today, t))
        return picks[:count]

    # ---------------- 主循环 ----------------

    def _current_life(self, now: dt.datetime | None = None) -> dict:
        now = now or dt.datetime.now()
        if not self._cfg("life_enabled"):
            return life_status(now)
        slots = normalize_slots(self._cfg("life_slots"))
        slot = current_slot(now, slots)
        items = (self.state.get("life") or {}).get("items") or {}
        item = items.get(f"{now.date().isoformat()}|{slot}")
        if item and item.get("text"):
            return item
        return life_status(now)

    async def _ensure_life(self, now: dt.datetime) -> None:
        """到刷新点就把这一刻的状态重新生成一次，一天里每个点只生成一次。"""
        if not self._cfg("life_enabled"):
            return
        slots = normalize_slots(self._cfg("life_slots"))
        slot = current_slot(now, slots)
        today = now.date().isoformat()
        cache = self.state.setdefault("life", {})
        items = cache.setdefault("items", {})
        key = f"{today}|{slot}"
        if key in items and items[key].get("text"):
            return
        if now.hour < 5:
            return
        logs = fetch_recent(
            int(self._cfg("life_log_limit") or 2000),
            int(self._cfg("life_log_chars") or 6000),
        )
        prev = None
        for k in sorted(items):
            if k.startswith(today) and k != key:
                prev = items[k]
        provider = str(self._cfg("life_provider") or "")
        persona = load_persona(str(self._cfg("persona_id") or ""))
        try:
            data = await generate_status(
                lambda p: _llm_text(self.context, p, provider, persona), now, logs, prev
            )
        except Exception as exc:
            logger.warning(f"[空间] 此刻状态生成异常: {type(exc).__name__}: {exc}")
            return
        if not data:
            logger.warning("[空间] 此刻状态生成失败，下轮再试")
            return
        items[key] = data
        cache["updated"] = now.isoformat()
        cache["items"] = {k: v for k, v in items.items() if k.startswith(today)}
        _save_state(self.state)
        logger.info(f"[空间] 此刻状态已更新（{slot}）：{data.get('text', '')[:40]}")

    async def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                now = dt.datetime.now()
                if self._plan_date != now.date().isoformat():
                    saved = self.state.get("plan") or {}
                    if saved.get("date") == now.date().isoformat() and saved.get("times"):
                        try:
                            self._plan = [
                                dt.datetime.fromisoformat(x) for x in saved["times"]
                            ]
                        except Exception:
                            self._plan = await self._build_plan(now.date())
                    else:
                        self._plan = await self._build_plan(now.date())
                    self._plan_date = now.date().isoformat()
                    self.state["plan"] = {
                        "date": self._plan_date,
                        "times": [m.isoformat() for m in self._plan],
                    }
                    _save_state(self.state)
                    self._published = {
                        item
                        for item in self._published
                        if item.startswith(self._plan_date)
                    }

                for moment in list(self._plan):
                    key = moment.strftime("%Y-%m-%d %H:%M")
                    if key in self._published:
                        continue
                    if 0 <= (now - moment).total_seconds() <= 300:
                        self._published.add(key)
                        await self._publish_once()

                await self._ensure_life(now)
                await self._maybe_reply(now)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning(f"[空间] 主循环异常: {exc}")
            await asyncio.sleep(30)

    # ---------------- 发布 ----------------

    async def _publish_once(self) -> None:
        status = self._current_life(dt.datetime.now())
        text = await compose_text(
            self.context,
            self._collect_cfg(),
            extra=f"此刻的状态（可自然带进句子里，不必全说）：{status['text']}",
        )
        if not text:
            logger.warning("[空间] 文案为空，这次不发")
            return
        images: list[bytes] = []
        if bool(self._cfg("image_enabled", True)):
            blob = await compose_image(self._collect_cfg(), f"{text}\n{scene_hint(status)}")
            if blob:
                images.append(blob)
        client = QzoneClient(self.context, timeout=90)
        async with aiohttp.ClientSession() as session:
            result = await client.publish(session, text, images)
            tid = str(result.get("tid") or "")
            ok = bool(tid) or str(result.get("code")) in ("0", "None")
            if ok and bool(self._cfg("auto_like", True)) and tid:
                await client.like(session, tid)
        self.state.setdefault("log", []).append(
            {
                "at": dt.datetime.now().isoformat(timespec="seconds"),
                "ok": ok,
                "images": len(images),
                "text": text[:80],
            }
        )
        self.state["log"] = self.state["log"][-200:]
        _save_state(self.state)
        logger.info(f"[空间] 发布{'成功' if ok else '失败'}，配图 {len(images)} 张")
        await self._notify(
            f"空间说说已发布（配图 {len(images)} 张）\n{text[:60]}"
            if ok
            else f"空间说说发布失败：{str(result)[:120]}"
        )

    def _collect_cfg(self) -> dict:
        keys = [
            "post_prompt",
            "text_provider",
            "image_enabled",
            "image_ratio",
            "image_style_prompt",
            "image_use_reference",
            "reference_image",
            "image_api_url",
            "image_model",
            "image_api_key",
            "image_timeout",
        ]
        return {k: self._cfg(k) for k in keys}

    # ---------------- 评论回复 ----------------

    async def _maybe_reply(self, now: dt.datetime) -> None:
        if not bool(self._cfg("reply_enabled", True)):
            return

        mode = str(self._cfg("reply_schedule_mode") or "slots").strip().lower()
        if mode == "slots":
            slots = normalize_slots(self._cfg("reply_slots") or ["09:00", "13:00", "19:00", "22:00"])
            slot = current_slot(now, slots)
            key = f"{now.date().isoformat()}|{slot}"
            done = self.state.setdefault("reply_slots", {})
            if done.get("date") != now.date().isoformat():
                done.clear()
                done["date"] = now.date().isoformat()
            if key in done:
                return
            # 到点了先记下来，避免这轮失败后每 30 秒重试一次
            done[key] = now.strftime("%H:%M")
            _save_state(self.state)
            if now.hour < 6:
                return
            await self._reply_round()
            return

        interval = max(5, int(self._cfg("reply_interval_minutes", 60) or 60)) * 60
        if now.timestamp() < self._next_reply_check:
            return
        self._next_reply_check = now.timestamp() + interval
        await self._reply_round()

    async def _reply_round(self) -> None:
        blacklist = {str(x).strip() for x in (self._cfg("reply_blacklist") or []) if str(x).strip()}
        keywords = [str(x) for x in (self._cfg("post_blacklist_keywords") or []) if str(x)]
        limit = max(1, int(self._cfg("reply_max_per_round", 3) or 3))
        replied = set(self.state.get("replied") or [])
        handled = 0

        client = QzoneClient(self.context, timeout=60)
        async with aiohttp.ClientSession() as session:
            posts = await client.my_last_posts(session, count=3)
            for post in posts:
                if handled >= limit:
                    break
                for comment in post.get("comments") or []:
                    if handled >= limit:
                        break
                    cid = comment.get("id") or ""
                    if not cid or cid in replied:
                        continue
                    if comment.get("reply"):
                        continue
                    if comment.get("uin") in blacklist:
                        continue
                    content = comment.get("content") or ""
                    if any(k and k in content for k in keywords):
                        continue
                    reply_text = await self._make_reply(comment)
                    if not reply_text:
                        continue
                    delay = random.randint(0, max(0, int(self._cfg("reply_delay_seconds", 120) or 0)))
                    if delay:
                        await asyncio.sleep(min(delay, 300))
                    ok = await client.reply_comment(
                        session,
                        tid=post.get("tid") or "",
                        curkey=post.get("curkey") or "",
                        comment_uin=comment.get("uin") or "",
                        comment_id=cid,
                        text=reply_text,
                    )
                    if ok:
                        replied.add(cid)
                        handled += 1

        self.state["replied"] = list(replied)[-600:]
        _save_state(self.state)
        if handled:
            logger.info(f"[空间] 本轮回复 {handled} 条评论")

    async def _make_reply(self, comment: dict) -> str:
        prompt = (
            f"{self._cfg('reply_prompt')}\n\n"
            f"对方的评论：{comment.get('content')}\n"
            f"对方昵称：{comment.get('name')}\n"
            "只输出回复正文，不要引号，不要解释。"
        )
        text = await compose_text(
            self.context,
            {
                "post_prompt": prompt,
                "persona_id": self._cfg("persona_id"),
                "text_provider": self._cfg("text_provider"),
            },
            str(self._cfg("text_provider") or ""),
        )
        return text[:80]

    # ---------------- 通知 ----------------

    async def _notify(self, text: str) -> None:
        uin = str(self._cfg("push_admin_uin") or "").strip()
        if not uin:
            return
        try:
            from astrbot.api.event import MessageChain

            await self.context.send_message(
                f"aiocqhttp:FriendMessage:{uin}", MessageChain().message(text)
            )
        except Exception as exc:
            logger.debug(f"[空间] 通知发送失败: {exc}")
